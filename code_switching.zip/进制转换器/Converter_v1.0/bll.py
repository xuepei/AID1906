"""

    逻辑控制层

"""


class Controller:
    """
        负责处理核心逻辑
    """

    def __init__(self):
        self.__tuple_2_system = (0, 1)
        self.__tuple_10_system = (0, 1, 2, 3, 4, 5, 6, 7, 8, 9)

    def two_to_ten(self, num):
        """
            二进制转换十进制逻辑
        :param num: 输入的值
        :return: 成功转换返回十进制数，否则返回None
        """
        while True:
            # 初始化每位相加之和
            result_2_to_10 = 0
            str_number = str(num)
            if not self.__is_two(num):
                return
            else:
                # 从左到右按位进行转换
                for item in range(len(str_number)):
                    result = int(str_number[item]) * 2 ** (len(str_number) - 1 - item)
                    # 将每一位转换完的数累加起来
                    result_2_to_10 += result
                # 输出十进制数
                return result_2_to_10

    def __is_two(self, num):
        """
            判断输入是否为二进制数
        :param num: 输入数字
        :return: 不是二进制数返回False，否则返回True
        """
        str_number = str(num)
        # 遍历每一位数字，判断输入数字是否为二进制
        for item in range(len(str_number)):
            if int(str_number[item]) not in self.__tuple_2_system:
                return False
        return True

    def ten_to_two(self, num):
        """
            十进制转换二进制逻辑
        :param num: 输入的值
        :return: 成功转换返回二进制数，否则返回None
        """
        while True:
            # 初始化输出结果
            if not self.__is_ten(num):
                return
            else:
                return self.__get_list_two(num)

    def __get_list_two(self, num):
        """
            根据输入数字获取二进制列表并拼接
        :param num: 输入的十进制数
        :return: 拼接出的二进制数
        """
        list_two = []
        int_num = int(num)
        while True:
            if int_num < 2:
                list_two.append(str(int_num % 2))
                break
            else:
                list_two.append(str(int_num % 2))
                int_num //= 2
        return "".join(list_two[::-1])

    def __is_ten(self, num):
        """
            判断输入是否为十进制数
        :param num: 输入数字
        :return: 不是十进制数返回False，否则返回True
        """
        str_number = str(num)
        # 遍历每一位数字，判断输入数字是否为十进制
        for item in range(len(str_number)):
            if int(str_number[item]) not in self.__tuple_10_system:
                return False
        return True
