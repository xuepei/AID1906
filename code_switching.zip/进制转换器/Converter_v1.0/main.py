"""

    2<--->10 转换器入口

"""
from usl import ConsoleView

if __name__ == '__main__':
    view = ConsoleView()
    view.main()
