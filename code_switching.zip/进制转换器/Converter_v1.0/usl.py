"""

    界面视图层

"""
from bll import Controller
import tkinter


class ConsoleView:
    """
        负责处理界面逻辑
    """

    def __init__(self):
        self.__controller = Controller()

    def __init_win(self):
        """
            初始化窗口
        """
        self.win = tkinter.Tk()
        self.win.title("进制转换器")
        self.win.geometry("380x150")
        self.__set_type()
        self.__set_button()

        self.win.mainloop()

    def __set_type(self):
        """
            基本布局
        """
        label_0 = tkinter.Label(self.win, text="进制转换器", font=("楷体", 20, "bold"))
        label_0.pack()

        label_1 = tkinter.Label(self.win, text="请输入待转换数字：")
        label_1.place(x=10, y=50)

        self.entry_1 = tkinter.Entry(self.win, width=13)
        self.entry_1.place(x=120, y=50)

        self.label_2 = tkinter.Label(self.win, fg="red")
        self.label_2.place(x=80, y=100)

        label_99 = tkinter.Label(self.win, text="1.0版本-by AID", font=("黑体", 10, "bold"))
        label_99.place(x=250, y=125)

    def __set_button(self):
        """
            设置按钮
        """
        button_1 = tkinter.Button(self.win, text="二进制转十进制", command=self.__two_to_ten)
        button_1.place(x=240, y=30)

        button_2 = tkinter.Button(self.win, text="十进制转十进制", command=self.__ten_to_two)
        button_2.place(x=240, y=70)

    def __two_to_ten(self):
        """
            二进制转十进制
        """
        try:
            self.__two_to_ten_core()
        except ValueError:
            self.label_2["text"] = "请输入一个整数"

    def __ten_to_two(self):
        """
            十进制转二进制
        """
        try:
            self.__ten_to_two_core()
        except ValueError:
            self.label_2["text"] = "请输入一个整数"

    def __two_to_ten_core(self):
        """
            二进制转十进制计算核心
        """
        num = self.entry_1.get()
        result = self.__controller.two_to_ten(num)
        if not result:
            self.label_2["text"] = "输入的不是二进制数"
        else:
            self.label_2["text"] = "转换结果为：%d" % result

    def __ten_to_two_core(self):
        """
            十进制转二进制计算核心
        """
        num = self.entry_1.get()
        result = self.__controller.ten_to_two(num)
        if not result:
            self.label_2["text"] = "输入的不是十进制数"
        else:
            self.label_2["text"] = "转换结果为：%s" % result

    def main(self):
        self.__init_win()


if __name__ == '__main__':
    view = ConsoleView()
    view.main()
